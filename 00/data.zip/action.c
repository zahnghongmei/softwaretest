Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	web_url("center.t.dacube.cn", 
		"URL=https://center.t.dacube.cn/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}