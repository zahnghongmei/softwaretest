Action()
{

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("login.jsp", 
		"URL=http://4a.dacube.com.cn/samlidp/login.jsp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t91.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=img/user.png", ENDITEM, 
		"Url=img/pass.png", ENDITEM, 
		"Url=img/userset.png", ENDITEM, 
		"Url=img/down.png", ENDITEM, 
		"Url=img/qrcode.png", ENDITEM, 
		"Url=img/close.png", ENDITEM, 
		"Url=img/1.png", ENDITEM, 
		"Url=img/close2.png", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_custom_request("urs.asmx", 
		"URL=https://urs.microsoft.com/urs.asmx?MSURS-Client-Key=sUDUyOYMCmGs64OSQ2WD9A%3d%3d&MSURS-MAC=lQsuHclCGnM%3d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=utf-8", 
		"Body=<RepLookup v=\"6\"><G>4A72F430-B40C-4D36-A068-CE33ADA5ADF9</G><O>00000000-0000-0000-0000-000000000000</O><DID>S7SLDAmA61aW9UyApSWhd0SpNI0mxVqjW5B3NWoIW4o=:0</DID><UID>w:2062F45C-33C6-17F4-8429-14DA68C62970</UID><D>10.0.8110.6</D><C>11.0.0.0</C><OS>10.0.17763.0.0</OS><I>9.11.17763.0</I><L>zh-CN</L><RU></RU><RI>0.0.0.0</RI><R><Rq><URL>aHR0cDovLzRhLmRhY3ViZS5jb20uY24vc2FtbGlkcC9sb2dpbi5qc3A=</URL><O>PRE</O><T>TOP</T><HIP>118.118.118.147</HIP></Rq><Rq><URL>aHR0cDovLzExOC4xMTguMTE4LjE0Nw==</URL><O"
		">PRE</O><T>IP</T><HIP>118.118.118.147</HIP></Rq></R><WA/><PRT/></RepLookup>", 
		LAST);

	web_custom_request("urs.asmx_2", 
		"URL=https://urs.microsoft.com/urs.asmx?MSURS-Client-Key=IoaYouKwxGozmGmcsgG9Gw%3d%3d&MSURS-MAC=xX2D7XPi4A4%3d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=utf-8", 
		"Body=<RepLookup v=\"6\"><G>4A72F430-B40C-4D36-A068-CE33ADA5ADF9</G><O>00000000-0000-0000-0000-000000000000</O><DID>S7SLDAmA61aW9UyApSWhd0SpNI0mxVqjW5B3NWoIW4o=:0</DID><UID>w:2062F45C-33C6-17F4-8429-14DA68C62970</UID><D>10.0.8110.6</D><C>11.0.0.0</C><OS>10.0.17763.0.0</OS><I>9.11.17763.0</I><L>zh-CN</L><RU></RU><RI>0.0.0.0</RI><R><Rq><URL>aHR0cDovLzRhLmRhY3ViZS5jb20uY24vc2FtbGlkcC9sb2dpbi5qc3A=</URL><O>POST</O><T>TOP</T><HIP>118.118.118.147</HIP></Rq><Rq><URL"
		">aHR0cDovLzRhLmRhY3ViZS5jb20uY24vc2FtbGlkcC9sb2dpbg==</URL><O>POST</O><T>ACTION</T><HIP>139.9.5.231</HIP></Rq><Rq><URL>aHR0cDovLzExOC4xMTguMTE4LjE0Nw==</URL><O>POST</O><T>IP</T><HIP>118.118.118.147</HIP></Rq></R><WA/><PRT/></RepLookup>", 
		LAST);

	web_custom_request("urstelemetry.asmx", 
		"URL=https://t.urs.microsoft.com/urstelemetry.asmx?MSTel-Client-Key=EMw2FejYcigh/pwVwwsLIA%3d%3d&MSTel-MAC=z8PnSETwepE%3d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t94.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=utf-8", 
		"Body=<T v=\"6\"><G>4A72F430-B40C-4D36-A068-CE33ADA5ADF9</G><D>10.0.8110.6</D><C>11.0.0.0</C><OS>10.0.17763.0.0</OS><I>9.11.17763.0</I><L>zh-CN</L><O>POST</O><ID>85BD2207-49DE-4C35-BC5D-113E17F7309D</ID><DID>S7SLDAmA61aW9UyApSWhd0SpNI0mxVqjW5B3NWoIW4o=:0</DID><UID>w:2062F45C-33C6-17F4-8429-14DA68C62970</UID><URL>aHR0cDovLzRhLmRhY3ViZS5jb20uY24vc2FtbGlkcC9sb2dpbi5qc3A=</URL><RU></RU><RI>0.0.0.0</RI><HIP>118.118.118.147</HIP><UI>01dce9fda0f9655585fb006461171f97a03f2ec109d1c2dc774d3ced8de00cb6</UI><S"
		">1088</S><DI>221.13.30.242</DI><Y><T>B|0|100.0000</T><T>I|0|100.0000</T><T>D|0|100.0000</T><T>P|0|100.0000|6.5000</T><T>F|2|0.0070|0.0070|0.0070</T><T>R|0|100.0000</T><T>U|2|5.0000</T><T>W|0|5.0000</T><T>H|0|100.0000</T><T>O|0|100.0000</T><T>T|0|100.0000</T><T>PP|1|100.0000</T></Y><M>NVHN</M><Fs><F><URL>aHR0cDovLzRhLmRhY3ViZS5jb20uY24vc2FtbGlkcC9sb2dpbi5qc3A=</URL><Z>NVHN</Z><H>10410000|14|0|80000064|FC0|0,2</H><K>3a003a00</K><T>TOP</T><HIP>118.118.118.147</HIP><SC/><SH>508a946d4616ea43</SH><NS></"
		"NS><SSL/><SSLLen/><REDIR/></F></Fs><WA/><GS/><Err/></T>", 
		LAST);

	return 0;
}